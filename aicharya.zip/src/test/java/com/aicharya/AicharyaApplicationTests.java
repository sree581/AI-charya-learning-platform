package com.aicharya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AicharyaApplicationTests {

	@Test
	void contextLoads() {
	}

}
